export interface IResponseMessage {
  success: boolean;
  status: number;
  message: unknown;
}
